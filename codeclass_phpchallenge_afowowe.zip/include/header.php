<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Bootstrap file loading -->
	<link href="include/css/bootstrap.min.css" rel="stylesheet"/>
	<link href="include/css/custom.css" rel="stylesheet"/>
	 <script type="text/javascript" src="include/js/jquery-1.10.2.min.js"></script>	
	 <script src="include/js/bootstrap.min.js"></script>
	<script src="include/js/respond.js"></script>
    <script type="text/javascript" src="include/js/tabpanel.js"></script>